/* The Receipt Eater — FIRST BUILD (prompt 1 output), kept verbatim for the episode.
   Three real faults, exactly as the first session produced them:
   (1) the amount = the LARGEST number on the receipt — cash tendered, "CREDIT LIMIT:
       $5,000.00" and change lines all outrank the real total;
   (2) dates: only M/D/Y with slashes is understood — ISO dates are invisible, and a
       card line's "EXP 11/27" is read as a date (month/year), so e-receipts land in
       November 2027;
   (3) every file that yields a number is logged — the same receipt saved twice is
       counted twice, a refund is counted as money spent, and files it can't read
       simply vanish from the log without a word. */
(function (g) {
  "use strict";
  function r2c(x) { return Math.round(x * 100); }
  function fmtD(t) { return t === null ? "(no date)" : new Date(t).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric", timeZone: "UTC" }); }
  const KEYWORDS = { "Inventory": ["bean", "coffee", "grocery", "market"], "Fuel": ["fuel", "gas", "pump"], "Supplies": ["hardware", "supply", "office", "packaging"], "Meals": ["diner", "cafe", "grill"], "Software": ["software", "internet"] };
  function analyze(files, settings) {
    const rows = [];
    for (const f of files) {
      const lines = (f.text || "").split(/\r?\n/);
      // the biggest number must be the total
      let best = null;
      for (const ln of lines) {
        for (const m of ln.matchAll(/\$?\s*(\d{1,3}(?:,\d{3})*\.\d{2})/g)) {
          const v = r2c(parseFloat(m[1].replace(/,/g, "")));
          if (best === null || v > best) best = v;
        }
      }
      if (best === null) continue;              // nothing numeric — skip it (silently)
      // date: first M/D/Y slash token; "11/27" style reads as month/year
      let t = null;
      outer:
      for (const ln of lines) {
        let m = ln.match(/(\d{1,2})\/(\d{1,2})\/(\d{2,4})/);
        if (m) { let y = +m[3]; if (y < 100) y += 2000; t = Date.UTC(y, +m[1] - 1, +m[2]); break outer; }
        m = ln.match(/(\d{1,2})\/(\d{2})(?!\d)/);
        if (m && +m[1] <= 12) { t = Date.UTC(2000 + +m[2], +m[1] - 1, 1); break outer; }   // EXP 11/27 -> Nov 2027
      }
      let vendor = "";
      for (const ln of lines) { if (ln.trim()) { vendor = ln.trim(); break; } }
      const hay = (f.text || "").toLowerCase();
      let cat = "Other";
      for (const k in KEYWORDS) if (KEYWORDS[k].some(w => hay.includes(w))) { cat = k; break; }
      rows.push({ file: f.name, t, date: fmtD(t), vendor, total: best, category: cat });
    }
    rows.sort((a, b) => (a.t || 0) - (b.t || 0));
    let totalC = 0; const cats = new Map();
    for (const r of rows) { totalC += r.total; cats.set(r.category, (cats.get(r.category) || 0) + r.total); }
    const categories = [...cats.entries()].map(([name, total]) => ({ name, total })).sort((a, b) => b.total - a.total);
    const vens = new Map();
    for (const r of rows) vens.set(r.vendor, (vens.get(r.vendor) || 0) + r.total);
    const vendors = [...vens.entries()].map(([name, total]) => ({ name, total })).sort((a, b) => b.total - a.total);
    const misdated = rows.filter(r => r.t !== null && r.t > Date.UTC(2026, 11, 31)).length;
    const undated = rows.filter(r => r.t === null).length;
    return { rows, money: { total: totalC }, categories, vendors,
             counts: { files: files.length, logged: rows.length, skipped: files.length - rows.length, misdated, undated } };
  }
  g.RE_V1 = { analyze };
})(typeof window !== "undefined" ? window : (typeof module !== "undefined" ? module.exports : this));
