THE RECEIPT EATER — Build It With AI, Episode 13
=================================================

One HTML file that eats a folder of receipt files — phone scans saved as text,
e-receipts, invoice emails — and hands back a clean expense log your bookkeeper
can import. Everything runs in your browser. Nothing is uploaded anywhere.

WHAT'S IN THIS ZIP
  index.html        the tool (open it in any modern browser — that's it)
  sample_receipts/  the 75-file sample folder from the episode
                    (Saltgrass Coffee Roasters — fictional, @example.com)
  PROMPTS.txt       the exact three prompts typed on camera
  first_build_engine_v1.js  the FIRST build, kept as it came out of prompt 1
                    (biggest-number totals, EXP 11/27 read as a date) - for comparison
  checker.py        the independent Python checker (same rules, no shared code)
                    usage: python3 checker.py < {"files":[{"name":..,"text":..}]}

HOW TO USE IT
  1. Open index.html in a browser (double-click it).
  2. Drop your receipt text files onto the page — or click "Load the sample
     folder" to see the episode's folder eaten live.
  3. Read the log. Edit the vendor→category map right on the page (one line
     per rule, like "bluewater=Vehicle") and it refiles itself.
  4. Download the CSV for your bookkeeper: date, vendor, category, amount,
     tax, source file.

WHAT IT PROMISES
  - Totals come from labeled lines (TOTAL, AMOUNT DUE), never "the biggest
    number on the page". Cash, change, YOU SAVED and credit-limit lines are
    furniture.
  - A card's EXP line never supplies the date.
  - Same-day twins merge (and say which files merged); near repeats a few
    days apart are flagged and kept.
  - Refunds carry their minus sign. Receipts that fail their own arithmetic
    are refused with the file name and the reason.
  - The page audits itself on every run: files in = logged + merged + refused,
    and categories = log total, to the cent. If a check fails, or more than 5%
    of files are refused, it prints DO NOT TRUST THIS LOG and says why.

IF YOUR RECEIPTS LOOK DIFFERENT
  The date-order setting handles day-first dates. For anything else, hand
  index.html and Prompt 1 to the AI and describe what your receipts look like —
  that's a five-minute conversation.

Checks behind this build: 207 cross-implementation runs against an independent
Python checker (0 disagreements) and 24 functional checks in a real browser
with the network blocked.

The sample business is fictional; every address and email is @example.com.
