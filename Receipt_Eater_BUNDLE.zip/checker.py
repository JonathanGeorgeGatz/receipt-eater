#!/usr/bin/env python3
"""Independent checker for The Receipt Eater — a from-scratch Python implementation
of the same spec. Shares no code with the tool. stdin: JSON {files:[{name,text}],
settings} -> stdout: JSON report matching engine.js fields (money in integer cents)."""
import sys, json, re, datetime as dt

MONTHS = {m: i + 1 for i, m in enumerate(["jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"])}

def valid_ymd(y, m, d):
    try:
        if y < 2000 or y > 2099: return None
        return dt.date(y, m, d)
    except ValueError:
        return None

def find_date(lines, order):
    cands = []
    for ln in lines:
        if re.search(r"exp|expiry|valid\s*thru|remit|ship", ln, re.I):
            continue
        m = re.search(r"(\d{4})-(\d{2})-(\d{2})", ln)
        if m:
            d = valid_ymd(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            cands.append((d, m.group(0))); continue
        m = re.search(r"(\d{1,2})/(\d{1,2})/(\d{2,4})", ln)
        if m:
            a, b, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
            if y < 100: y += 2000
            mo, da = (b, a) if order == "DMY" else (a, b)
            d = valid_ymd(y, mo, da)
            cands.append((d, m.group(0))); continue
        m = re.search(r"([A-Za-z]{3,9})\.?\s+(\d{1,2}),?\s+(\d{4})", ln)
        if m and m.group(1)[:3].lower() in MONTHS:
            d = valid_ymd(int(m.group(3)), MONTHS[m.group(1)[:3].lower()], int(m.group(2)))
            cands.append((d, m.group(0))); continue
        m = re.search(r"(\d{1,2})\s+([A-Za-z]{3,9})\.?\s+(\d{4})", ln)
        if m and m.group(2)[:3].lower() in MONTHS:
            d = valid_ymd(int(m.group(3)), MONTHS[m.group(2)[:3].lower()], int(m.group(1)))
            cands.append((d, m.group(0)))
    if not cands:
        return None, "no date anywhere on it"
    good = [c for c in cands if c[0] is not None]
    if not good:
        return None, 'its date isn\'t a real calendar day: "%s"' % cands[0][1]
    return good[0][0], None

MONEY = re.compile(r"-?\$?\s*(-?\d{1,3}(?:,\d{3})*(?:\.\d{2}))\b")

def amounts(lines):
    out = {"total": None, "subtotal": None, "tax": None, "tip": None, "refund": False}
    for ln in lines:
        low = ln.lower()
        m = MONEY.search(ln)
        if not m:
            continue
        v = round(float(m.group(1).replace(",", "")) * 100)
        neg = -1 if ("-$" in ln or re.search(r"\s-\d", ln)) else 1
        v = abs(v) * neg if neg < 0 else v
        if re.search(r"cash|tend|change|credit limit|you saved|save[sd]?\b|balance forward|points|reward", low):
            continue
        if "refund" in low:
            out["refund"] = True
            out["total"] = -abs(v)
            continue
        if re.search(r"sub\s*-?total", low):
            out["subtotal"] = v; continue
        if re.search(r"\btax\b", low):
            out["tax"] = (out["tax"] or 0) + v; continue
        if re.search(r"tip|gratuity", low):
            out["tip"] = v; continue
        if re.search(r"amount due|grand total|order total|^total\b|\btotal\b", low) and "fuel total" not in low:
            out["total"] = v; continue
        if low.startswith("fee:") or "booth fee" in low:
            out["total"] = v; continue
        if "amount charged" in low:
            out["total"] = v; continue
    return out

def vendor_of(lines):
    for ln in lines:
        m = re.match(r"^Subject:.*[—-]\s*(.+?)\s*$", ln, re.I)
        if m:
            return m.group(1).strip()
    for ln in lines:
        t = ln.strip()
        if not t:
            continue
        if re.match(r"^(from|subject|to):", t, re.I):
            continue
        v = re.sub(r"\s+[—-]\s+(order confirmation|payment received).*$", "", t, flags=re.I)
        v = re.sub(r"—.*$", "", v).strip()
        if re.match(r"^\d+[/-]", v) or re.match(r"^(date|invoice \d|order #)", v, re.I):
            continue
        return re.split(r"\s{3,}", v)[0].strip()
    return "(unreadable)"

def title_case(s):
    if s != s.upper():
        return s
    t = re.sub(r"\b[a-z]", lambda m: m.group(0).upper(), s.lower())
    t = re.sub(r"\b(\d+[a-z]*)\b", lambda m: m.group(0).upper(), t, flags=re.I)
    return t

def ven_key(v):
    return re.sub(r"[^a-z0-9]", "", v.lower())

def cat_for(vendor, catmap):
    low = vendor.lower()
    for line in catmap.split("\n"):
        i = line.find("=")
        if i < 1:
            continue
        k = line[:i].strip().lower()
        v = line[i + 1:].strip()
        if k and k in low:
            return v
    return "Uncategorized"

def fmt_d(d):
    return d.strftime("%b ") + str(d.day)

DEF_CATMAP = "\n".join([
    "bean=Inventory — beans", "coffee=Inventory — beans", "roast=Inventory — beans",
    "packaging=Packaging", "cup=Packaging",
    "fuel=Vehicle", "gas=Vehicle",
    "hardware=Repairs & maintenance", "espresso parts=Repairs & maintenance", "restaurant supply=Equipment & smallwares",
    "grocery=Inventory — dairy & goods", "market & main=Inventory — dairy & goods",
    "office=Office & admin", "software=Software & subscriptions", "internet=Utilities",
    "diner=Meals", "cafe=Meals",
    "farmers market=Selling fees", "booth=Selling fees", "parking=Vehicle",
])

def main():
    inp = json.load(sys.stdin)
    S = {"dateOrder": "MDY", "dupDays": 3, "month": "all", "catmap": DEF_CATMAP}
    S.update(inp.get("settings") or {})
    refused = []
    rows = []
    for f in inp["files"]:
        lines = (f.get("text") or "").split("\n")
        if not "".join(lines).strip():
            refused.append({"file": f["name"], "reason": "empty file"}); continue
        d, why = find_date(lines, S["dateOrder"])
        if d is None:
            refused.append({"file": f["name"], "reason": why}); continue
        a = amounts(lines)
        if a["total"] is None:
            refused.append({"file": f["name"], "reason": "no line on it reads as a total"}); continue
        if a["subtotal"] is not None and not a["refund"]:
            s = a["subtotal"] + (a["tax"] or 0) + (a["tip"] or 0)
            if abs(s - a["total"]) > 1:
                refused.append({"file": f["name"], "reason": "its own math fails"}); continue
        rows.append({"file": f["name"], "d": d, "iso": d.isoformat(), "date": fmt_d(d),
                     "vendor": title_case(vendor_of(lines)), "total": a["total"],
                     "tax": a["tax"] or 0, "tip": a["tip"] or 0, "refund": a["refund"]})
    rows.sort(key=lambda r: (r["d"], r["file"]))
    dups = []
    flags = []
    seen = []
    for r in rows:
        same = next((s for s in seen if ven_key(s["vendor"]) == ven_key(r["vendor"]) and s["total"] == r["total"] and s["d"] == r["d"]), None)
        if same:
            r["dup"] = True
            dups.append((same, r)); continue
        near = next((s for s in seen if ven_key(s["vendor"]) == ven_key(r["vendor"]) and s["total"] == r["total"]
                     and abs((r["d"] - s["d"]).days) <= S["dupDays"]), None)
        if near:
            flags.append((near, r, abs((r["d"] - near["d"]).days)))
        seen.append(r)
    def in_scope(r):
        return S["month"] == "all" or r["iso"][:7] == S["month"]
    log_rows = [r for r in rows if not r.get("dup") and in_scope(r)]
    dup_rows = [r for r in rows if r.get("dup") and in_scope(r)]
    out_scope = len([r for r in rows if not in_scope(r)])
    for r in log_rows:
        r["category"] = cat_for(r["vendor"], S["catmap"])
    totalC = sum(r["total"] for r in log_rows)
    taxC = sum(r["tax"] for r in log_rows)
    refC = sum(r["total"] for r in log_rows if r["total"] < 0)
    cats = {}
    unc = []
    for r in log_rows:
        cats[r["category"]] = cats.get(r["category"], 0) + r["total"]
        if r["category"] == "Uncategorized":
            unc.append(r)
    categories = sorted([{"name": k, "total": v} for k, v in cats.items()], key=lambda c: -c["total"])
    vens = {}
    for r in log_rows:
        vens[r["vendor"]] = vens.get(r["vendor"], 0) + r["total"]
    vendors = sorted([{"name": k, "total": v} for k, v in vens.items()], key=lambda v: -v["total"])
    files_in = len(inp["files"])
    files_tie = len(log_rows) + len(dup_rows) + len(refused) + out_scope == files_in
    cat_sum = sum(c["total"] for c in categories)
    cat_tie = cat_sum == totalC
    share = len(refused) / max(1, files_in)
    trusted = files_tie and cat_tie and share <= 0.05
    print(json.dumps({
        "rows": [{"file": r["file"], "iso": r["iso"], "vendor": r["vendor"], "total": r["total"],
                  "tax": r["tax"], "category": r["category"]} for r in log_rows],
        "dups": [[a["file"], b["file"], a["total"]] for (a, b) in dups],
        "flags": [[a["vendor"], a["total"], days] for (a, b, days) in flags if in_scope(b)],
        "refusedFiles": sorted(x["file"] for x in refused),
        "money": {"total": totalC, "tax": taxC, "refunds": refC},
        "categories": categories, "vendors": vendors, "uncCount": len(unc),
        "recon": {"filesIn": files_in, "logged": len(log_rows), "duplicates": len(dup_rows),
                  "refused": len(refused), "outOfScope": out_scope, "filesTie": files_tie,
                  "catSum": cat_sum, "catTie": cat_tie, "trusted": trusted},
    }))

main()
